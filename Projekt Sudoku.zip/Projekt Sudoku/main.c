#include <stdio.h>
#include <stdlib.h>


//Feld auswahl + Wert hinzuf�gen
int main()
{
//    char feld;

//    printf("Projekt Sudoku\n");
//    printf("Feld auswaehlen: ");
 //   scanf("%c", &feld);

 //   if (feld != "")
 //   {
 //       printf("Eingabe: %c", feld);
 //   }


//    int i, punkte[5] = { 1, 3, 5, 7, 9 };
//    int i, feld[9];
//
//
//
//    // Werte ausgeben
//    for(i=0; i<9; i++) {
//        printf("Wert eingeben: ");
//        scanf("%d", &feld[i]);
//    }
//
//    for (i=0; i<9; i++) {
//         printf("Wert Index %d: %d\n", i, feld[i]);
//    }




    /* an array with 5 rows and 2 columns*/
       char a[9][9];
       int i, j;

       /* output each array element's value */
//        for(i=9; i<9; i++){
//            printf("Wert eingeben: ");
//            scanf("Feld: [%c]\n", a[i]);
//        }
//
//        for(i=9; i<9; i++){
//            printf("Wert eingeben: ");
//            scanf("Feld: [%c]", a[j]);
//        }
        printf("Wert eingeben: \n");
       for ( i = 0; i < 9; i++ ) {

          for ( j = 0; j < 9; j++ ) {
            a[i][j] = '0';

             scanf("Feld: [%c]\n", a[i]);
            scanf("Feld: [%c]\n", a[j]);

          }
       }



    return 0;
}


//Quelle:

//https://www.tutorialspoint.com/cprogramming/c_multi_dimensional_arrays.htm

